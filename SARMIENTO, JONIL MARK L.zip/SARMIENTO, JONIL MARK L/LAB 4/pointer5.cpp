#include <stdio.h> 
#include <string.h> 
#include <iostream>

using namespace std;
  
// Function to reverse the string 
// using pointers 
void reverseString(char* str) 
{ 
    int l, i; 
    char *beginptr, *endptr, ch; 
  
    // Get the length of the string 
    l = strlen(str); 
  
    // Set the begin_ptr and end_ptr 
    // initially to start of string 
    beginptr = str; 
    endptr = str; 
  
    // Move the end_ptr to the last character 
    for (i = 0; i < l - 1; i++) 
        endptr++; 
  
    // Swap the char from start and end 
    // index using begin_ptr and end_ptr 
    for (i = 0; i < l / 2; i++) { 
  
        // swap character 
        ch = *endptr; 
        *endptr = *beginptr; 
        *beginptr = ch; 
  
        // update pointers positions 
        beginptr++; 
        endptr--; 
    } 
} 
  
// Driver code 
int main() 
{ 
  
    // Get the string 
    char string[100]; 
    
  cout << "Enter a String: \n";
  cin >> string;
  
    // Reverse the string 
    reverseString(string); 
  
  cout << "New String: " << string;
  
    return 0; 
} 
