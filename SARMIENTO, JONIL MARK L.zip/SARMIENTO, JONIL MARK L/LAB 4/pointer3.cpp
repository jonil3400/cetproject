#include<stdio.h>
#include <iostream>
 using namespace std;
 
int compare_string(char*, char*);
 
main()
{
    char fword[100], sword[100], result;
 
    cout<<"Enter first word\n";
    cin.getline(fword,100);
 
  	cout<<"Enter secomd word\n";
    cin.getline(sword,100);
 
 
    result = compare_string(fword, sword);
 
    if ( result == 0 )
      cout<<"Enter words are Equal\n";
    else
  	cout<<"Enter words are Not  Equal\n"; 
    return 0;
}
 
int compare_string(char *first, char *second)
{
   while(*first==*second)
   {
      if ( *first == '\0' || *second == '\0' )
         break;
 
      first++;
      second++;
   }
   if( *first == '\0' && *second == '\0' )
      return 0;
   else
      return -1;
}
