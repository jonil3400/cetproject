#include <iostream> 
using namespace std; 
  
// function to find the length 
// of the string through pointers 
int stringLength(char* string) 
{ 
    // variable to store the 
    // length of the string 
    int length = 0; 
    while (*string != '\0') { 
        length++; 
        string++; 
    } 
  
    return length; 
} 
  
// Driver function 
int main() 
{ 
    
    char string1[100]; 
    cout << "Enter The String: \n";
    cin >> string1;
    
    cout<< stringLength(string1); 
    return 0; 
} 
