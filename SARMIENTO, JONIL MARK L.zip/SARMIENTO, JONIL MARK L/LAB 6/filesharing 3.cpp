#include <iostream>
using namespace std;

int main()
{
	FILE *fp;
	fp= fopen ("D:\\SARMIENTO, JONIL MARK L\\LAB 6\\w.txt","w");
	
	if (!fp)
	{
		
			cout << "Cannot open file. \n";
			system("pause");
			exit(1);
			
	}
	
	fputc('\n', fp);
	
	for(int i=97;i<123;i++)
		fputc(i,fp);
		
	fclose(fp);
	return 0 ;
}
