#include <iostream>
using namespace std;
int main()
{
	FILE *fp;
	fp= fopen ("D:\\SARMIENTO, JONIL MARK L\\LAB 6\\w.txt","w");
	
	if (!fp)
	{
		cout << " Cannot Open File.\n";
		system("pause");
		exit(1);
		
	}	
	char c;
	while ((c = fgetc(fp))!=EOF)
			cout <<c;
			
	fclose(fp);
	system("pause > 0");
	return 0 ;

}
