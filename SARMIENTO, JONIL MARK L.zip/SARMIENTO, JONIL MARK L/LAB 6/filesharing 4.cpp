#include <iostream>
using namespace std;

int main()
{
		FILE *fp;
		fp= fopen ("D:\\SARMIENTO, JONIL MARK L\\LAB 6\\w.txt","w");
		
		if (!fp)
		{
				cout << "Cannot Open Files \n";
				system("pause");
				exit(1);
				
		}

	fputs("sample string 1\n", fp);
	fputs("sample string 2", fp);
	
	fclose(fp);
	return 0;

}
