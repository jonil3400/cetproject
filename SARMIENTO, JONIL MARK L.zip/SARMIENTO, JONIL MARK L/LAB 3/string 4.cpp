#include <iostream>
#include <cstring>
using namespace std;

bool isAPalindrome(char* palindrome);


int main()
{
	
		cout << "PALINDROME" << std::endl;

    char palindrome[30];
    bool palindrome_check;

    cout << "Please enter an word or phrase.\n";
    cin.getline(palindrome, 30);

    palindrome_check = isAPalindrome(palindrome);

    if (palindrome_check == true)
    {
        cout << palindrome << " is a palindrome\n";
    }
    else
    {
        cout <<palindrome << " is not a palindrome\n";
    }
	system("pause");
	return 0;
}


bool isAPalindrome(char* palindrome)
{
	// if palindrome is NULL, terminate immediately. Dereferencing
	// a null pointer will blow up the program.
	if(NULL == palindrome)
		return false;

	// find the first non-whitespace char (now we know we have some chars)
	char* front = palindrome;
	while(isspace(*front))
	{
		++front;
	}

	// find out how much longer the string is, from the first non-
	// non-whitespace char. If the answer's zero, then we were passed
	// a string containing only whitespace
	size_t len = strlen(front);
	if(0 == len)
		return false;

	// find the last non-whitespace char
	char* rear = front + len - 1;
	while(isspace(*rear))
	{
		--rear;
	}

	while (front <= rear)
	{
#if 0 // enable for debugging
		cerr << *front << " - " << *rear << endl;
#endif

		if ((*front) != (*rear))
			return false;

		do
		{
			++front;
		} while(isspace(*front));

		do
		{
			--rear;
		} while(isspace(*rear));
	}

	return true;
}
