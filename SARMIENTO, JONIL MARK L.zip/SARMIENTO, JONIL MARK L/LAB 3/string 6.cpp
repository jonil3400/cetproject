#include <iostream> 
#include <string> 

  using namespace std; 

int main ()
{ 
    string sentence; 
    string newSentence;
    string::size_type pos1; 
    string::size_type pos2; 

    string::size_type len; 

    cout << "Enter a String\n"<<endl;

    getline(cin, sentence); 
    pos1 = 0; 
    len = sentence.length(); 
    pos2 = sentence.find(' ',pos1); 
    while (pos2 != string::npos)
        {
            newSentence = sentence.substr(pos1, pos2-pos1+1) + newSentence; 
            pos1 = pos2 + 1;
            pos2 = sentence.find(' ',pos1);       
        }
    newSentence = sentence.substr(pos1, len-pos1+1) + " "  + newSentence;
    cout << endl << newSentence  <<endl; 

    return 0;

}
