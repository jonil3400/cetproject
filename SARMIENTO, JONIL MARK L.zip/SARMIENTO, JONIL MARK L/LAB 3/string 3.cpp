#include<iostream>
 
using namespace std;
 

int main()
{

	char fword[30],sword[30],tword[60];
	int i,j;
	cout<<"Enter first word:";
	gets(fword);
	cout<<"\nEnter second word:";
	gets(sword);
	
	for(i=0;fword[i]!='\0';++i)
		tword[i]=fword[i];
		
	for(j=0;sword[j]!='\0';++j)
		tword[i+j]=sword[j];
		
	tword[i+j]='\0';
	
 
	return 0;
}


