#include <iostream>
#include <string.h>
using namespace std;

char mainQ = 'y'; 

void stringCpy(char* s1,char* s2);

int main()
{
 	
 	while (mainQ=='Y'||mainQ=='y')
	 {
	  	
	cout << "STRING COPY " << std::endl;
		
	char fword[50];
	char sword[50];
	
	system("CLS");
 	cout << "Enter a First Word(str1): " << std::endl;
 	
	cin.getline(fword,100);
	
	cout << "Enter a Second Word(str2): " << std::endl;
	
	cin.getline(sword,50);
 

	stringCpy(fword, sword);
 
 
		std::cout << "New value for str1: " << fword << std::endl;
	
 		cout<<"\n Process complete. Wanna try again? (enter 'y' if YES)\n"<<std::endl;
		cout<<">> ";
		
			
		cin>>mainQ;

}
return 0;

}

void stringCpy(char* s1,char* s2)
{
    int i=0;
    while(s2[i]!='\0')
    {
        s1[i]=s2[i];
        i++;
    }
    s1[i]='\0'; /*string terminates by NULL*/
}
