#include<iostream>
#include<stdio.h>
#include<ctype.h>
#include<string.h>
using namespace std;


 
int main()
{
 	
	
    int i;
    char word[30];
    
  
    cout << "CAPITALIZATION " << std::endl;

    cout<<"\nEnter some string :: ";
    gets(word);
 
    int len = strlen(word);
 
    for(i=0;i<len;++i)
    {
        if(i==0)
        {
            if(islower(word[i]))
            word[i]=toupper(word[i]);
        }
        else
        {
            if(word[i]!=' ')
            {
                if(isupper(word[i]))
                    word[i]=tolower(word[i]);
            }
            else
            {
                i++;
                if(islower(word[i]))
                    word[i]=toupper(word[i]);
            }
        }
    }
    cout<<"\nUpdated New String is :: "<<word<<"\n";
   
 
    return 0;
}
