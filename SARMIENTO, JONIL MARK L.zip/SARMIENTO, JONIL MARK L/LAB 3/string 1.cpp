#include <iostream>
#include <string.h>
using namespace std;

char mainQ = 'y'; 


int main()
{
 	
 	while (mainQ=='Y'||mainQ=='y')
	 {
	 	
	cout << "STRING COMPARE " << std::endl;

	char fword[50];
	char sword[50];
	
	system("CLS");
 	cout << "Enter First Word" << std::endl;
 	
	cin >> fword;
	
	cout << "Enter Second Word" << std::endl;
	
	cin >> sword;
 

	int result = strcmp(fword, sword);
 
	if (result == 0)
		std::cout << "equal" << std::endl;
	else if(result > 0)
		std::cout << "positive";
	else
		std::cout<<"negative";
  
	

 		cout<<"\n Process complete. Wanna try again? (enter 'y' if YES)\n"<<std::endl;
		cout<<">> ";
		
			
		cin>>mainQ;
}
return 0;
}
