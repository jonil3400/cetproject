#include <iostream>

using namespace std;

int main()

{
int c;
bool start= true;
char mainQ= 'Y';

while (start != false)
{
 system ("CLS");
cout << " 1.) Area of  square \n";
cout << " 2.) Area of rectangle\n";
cout << " 3.) Area of triangle\n";
cout << " 4.) Area of circle \n";
cout << " 5.) Exit \n";
cout << " Enter your choice : ";

cin >> c;


switch (c)
{

case 1:
 system ("CLS");	
cout << "Enter the side of square \n";
	int s, a1;
	cin >> s;
	a1 = s * s;
	system ("CLS");
	cout << "The area of square is "<<a1<< " sq.units\n";
	 system ("Pause");
break;


case 2:
	 system ("CLS");
cout << "Enter the length: ";
	int w, l, a2;
	cin >> l;
cout << "Enter width: ";
	cin >> w;
	a2 = l * w;
	system ("CLS");
	cout << "The area of rectangle is "<<a2<< " sq.units\n";
	 system ("Pause");
break;


case 3:
	 system ("CLS");
cout << "Enter base: ";
	int b, h, a3;
	cin >> b;
cout << "Enter height: ";
	cin >> h;
	a3 = (b * h) / 2;
	system ("CLS");
	cout << "The area of triangle is "<<a3<< " sq. units\n";
	 system ("Pause");
break;


case 4:
	system ("CLS");
cout << "Enter radius \n";
	double r, a4;
	cin >> r;
	a4 = (r*r)*3.141592;
	system ("CLS");
	cout << "The area of circle is "<<a4<< " sq. units\n";
	 system ("Pause");
break;


case 5:
system ("CLS");
cout << "Thank you! \n";
start = false;
return 0;

default:
int c=0;
cout << "Invalid Input. \n";
cout << "Choose again.\n";
cin >> c ;
return 0;

}


}

}
	
