#include <iostream>
#include <cmath>

using namespace std;
char mainQ = 'y';

	double max (double x, double y){
	double ans;
	
		if(x>y){
			ans = x;
		}
		else if (y>x){
			ans = y;
		}
	}
	
	int main(){
		    while (mainQ=='Y'||mainQ=='y')
    {
    	system ("cls");	
		double x,y;
		cout<<"Enter first number: " << endl;
		cin>>x;
		cout<<"Enter second number: "<< endl;
		cin>>y;	
		if(!cin)
        {
        	system ("CLS");
			cout<<"Wrong Input";
		return 0;
		}
		
		if ( x== y){
			cout << " They are Equal" << endl;
			std::cout<<" Wanna try again? (enter 'y' if YES) \n"<<std::endl;
		cout<<">> ";
		cin>>mainQ;	
		}
		else {
		cout<<"The greatest number is "<< max(x,y)<<endl;
		std::cout<<" Wanna try again? (enter 'y' if YES) \n"<<std::endl;
		cout<<">> ";
		cin>>mainQ;	
}
}
}
	
