#include <iostream>
using namespace std;

int factorial(int);
int negFactorial(int);

char mainQ = 'y';

int main()
{
  while (mainQ=='Y'||mainQ=='y'){
  
  
   int n;
system ("CLS");
   cout<< "Enter a number: " ;
   cin >> n;
   cout << endl;
   if(!cin)
        {
        	system ("CLS");
			cout<<"Wrong Input";
		return 0;
		}
   
   else if (n>0)
     {
     	system ("CLS");
	   cout << " The factorial of " << n << " is " << factorial(n) << endl;
    	cout<<"\nWanna try again? (enter 'y' if YES)\n"<<std::endl;
		cout<<">> ";		
		cin>>mainQ;	
    }
    	
   else if (n<0)
   {
   system ("CLS");
      cout << " Wrong Input" << endl;
      cout<<"\nWanna try again? (enter 'y' if YES)\n"<<std::endl;
		cout<<">> ";		
		cin>>mainQ;
      }
   else{
   system ("CLS");
      cout << " The facotial of 0 is 1" << endl;
      cout<<"\nWanna try again? (enter 'y' if YES)\n"<<std::endl;
		cout<<">> ";		
		cin>>mainQ;
      }  
}

}


int factorial(int n)
{
  if(n <= 1)
   return 1;
  else
   return (n * factorial(n - 1));
}


