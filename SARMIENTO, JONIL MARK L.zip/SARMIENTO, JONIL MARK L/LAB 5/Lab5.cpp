
#include <algorithm>
#include <iostream> 
#include <string> 
#include <fstream> 
#include <cmath>
#include <windows.h> 
#include <vector>
#include <cstdlib>
#include<ctype.h>
#include<iomanip>
#define MAX 100000


using namespace std;

void gotoxy(short x, short y){ 
	COORD pos = { x, y };
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), pos);
}




bool dblcheck(string userin){ 

	bool dblstatus = false;
	for (int i = 0; i < userin.size(); i++) {
		if (i == 0 && userin[i] == '-') {
			dblstatus = false;
			continue;
		}
		if (isdigit(userin[i]) || userin[i] == '.') {
			dblstatus = false;
		} else {
			dblstatus = true;
			break;
		}
	}
	return dblstatus;
}

bool inNega(string userin){ 

    int i = 0;
    for (int i = 0; i < userin.size(); i++){
        if (userin[i] == '-'){
            return true;
        }
        else return false;
    }
}



struct stud{

	string id;
	string name;
	float quiz[3];
};

float quizave(stud a){

	return (a.quiz[0]+a.quiz[1]+a.quiz[2])/3;
}

string remarks(stud a){

	if (quizave(a) > 75){
		return "Passed";
	}
	else{
		return "Failed";
	}
}


void error(){ 

	system("cls");
	cout << "Error"<< endl ;
	system("pause");
}


string anotTry; 

int main(){
   
a:
	cout << "Select Program" << endl;
	cout << "1: Three Quizess" << endl;
	cout << "2: Five Stud Records" << endl;
	string select = "";
	string userIn = "";
	getline(cin, select); 


b:	system("cls");

	if (select == "1"){ 
	    system("cls");
	    stud C;
        cout << "Enter Stud Record: \n";

        cout << "ID: ";
        getline(cin, userIn);
        if (userIn == ""){ 
                error();
                goto b;
        }
        C.id = userIn;

        cout << "Name: ";
        getline(cin, userIn);
        if (userIn == ""){ 
                error();
                goto b;
        }
        C.name = userIn;

        cout << "Quiz 1: ";
        getline(cin, userIn);

        if (dblcheck(userIn) || inNega(userIn) || userIn == "0" || userIn == "-0" || userIn == ""){ 
                goto b;
        }

        C.quiz[0] = atoi(userIn.c_str()); 

        cout << "Quiz 2: ";
        getline(cin, userIn);

        if (dblcheck(userIn) || inNega(userIn) || userIn == "0" || userIn == "-0" || userIn == ""){ 
                error();
                goto b;
        }

        C.quiz[1] =atoi(userIn.c_str()); 

        cout << "Quiz 3: ";
        getline(cin, userIn);

        if (dblcheck(userIn) || inNega(userIn.c_str()) || userIn == "0" || userIn == "-0" || userIn == ""){ 
                error();
                goto b;
        }

        C.quiz[2] = atoi(userIn.c_str()); 

        cout << endl << endl;

        cout << "Stud Record: \n";
        cout << "ID: " << C.id << endl;
        cout << "Name: " << C.name << endl;
        cout << "Grades : " << quizave(C) << endl;
        cout << "Remarks: " << remarks(C) << endl << endl;

        cout << "Try Again? (y/n): ";
        getline(cin, anotTry);
        if(anotTry == "y" || anotTry == "Y"){
             string userIn = "";
             goto b;
        }
        else if(anotTry == "n" || anotTry == "N"){
             cout << "\nReturning to main menu... "; system("pause"); system("cls");
             goto a;
        }
        else{
             error();
             goto b;
        }



	}
	else if(select == "2"){
        system("cls");
	    stud a[5];
	    int i,j;
	    string QuizUser[3];
	    int QuizUser1[3];
	    cout << "Enter 5 Stud Records: \n\n";
	    for(i=0; i<5; ++i){
	        cout << "Stud " << i+1 << endl;
            cout << "ID: ";
            getline(cin, a[i].id);
            cout << "Name: ";
            getline(cin, a[i].name);
            cout << "Enter 3 Quizzes: \n";
            for(j=0; j<3; ++j){

                getline(cin, QuizUser[j]);

                if (dblcheck(QuizUser[j]) || inNega(QuizUser[j]) || QuizUser[j] == "-0" || QuizUser[j] == ""){ 
                error();
                goto b;
                }

                QuizUser1[j] = atoi(QuizUser[j].c_str()); 
                a[i].quiz[j] = QuizUser1[j];
            }
            cout << endl;
	    }

        cout << endl;
        cout << setw(10) << "No.";
        cout << setw(16) << "Student No.";
        cout << setw(30) << "Name";
        cout << setw(10) << "Grade";
        cout << setw(10) << "Remark";

        cout.setf(ios::fixed);
        cout.setf(ios::showpoint);
        cout.precision(2);


	    for(i=0; i<5; ++i){
            cout << endl;
            cout << setw(10) << i+1;
            cout << setw(16) << a[i].id;
            cout << setw(30) << a[i].name;
            cout << setw(10) << quizave(a[i]);
            cout << setw(10) << remarks(a[i]);
	    }

	    cout << endl << endl << endl;

        cout << "Try Again? (y/n): ";
        getline(cin, anotTry);
        if(anotTry == "y" || anotTry == "Y"){
             string userIn = "";
             goto b;
        }
        else if(anotTry == "n" || anotTry == "N"){
             cout << "\nReturning to main menu... "; system("pause"); system("cls");
             goto a;
        }
        else{
             error();
             goto b;
        }
	}


	else if (select == "3"){
		
	}

	else if (select == "4"){
        exit(0); 
	}

	else{ 
        error();
        goto a;
	}

}







