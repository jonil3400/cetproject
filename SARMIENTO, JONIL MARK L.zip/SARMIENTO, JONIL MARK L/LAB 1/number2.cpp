#include <iostream>
using namespace std;

int factorial(int);
int negFactorial(int);

char mainQ = 'y';

int main()  
{  

	while (mainQ=='Y'||mainQ=='y')
	 {
	   
	system ("CLS");
	
	int number;
		system ("CLS");
   		cout << endl << " Enter a Number " ;
   		cin >> number;
   		cout << endl;
   			if (number>0)
      		cout << " The " << number << "! is " << factorial(number) << endl;
		   else if (number<0)
		      system ("CLS");
			  cout << " Invalid Output "   << endl;
		   else
		      system ("CLS");
			  cout << " The 0! is 1" << endl;
		
		   return 0;

	
	    
	
	
	}
cout<<"\n Process complete. Wanna try again? (enter 'y' if YES)\n"<<std::endl;
		cout<<">> ";
		
			
		cin>>mainQ;
}

}    
	  
	  
	  int factorial(int number)
{
  if(number <= 1)
   return 1;
  else
   return (number * factorial(number - 1));
}

