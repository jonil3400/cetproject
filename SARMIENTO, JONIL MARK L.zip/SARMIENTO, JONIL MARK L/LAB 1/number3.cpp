    #include<iostream>

    using namespace std;

char mainQ = 'y';
double arr[10]; int  m, n, x;

    int main ()

    {

        while (mainQ=='Y'||mainQ=='y')
	 {
		system ("CLS");
        cout << "Enter ten numbers : \n";

        for (m = 0; m < 10; m++)

            cin >> arr[m];
			    

        for (m = 0; m < 10; m++)

        {

            for (n = m + 1; n < 10; n++)

            {
				if(!cin)
        {
        	system ("CLS");
			cout<<"Wrong Input";
			
			return 0;
    
		}
		
                if (arr[m] < arr[n])
				
                {

                    x = arr[m];

                    arr[m] = arr[n];

                    arr[n] = x;

                }

            }

        }
        system ("CLS");
        cout << "First to the highest : " << arr[0];
        cout << "\nSecond to  the highest : " << arr[1];
        cout << "\nFirst to the lowest : " << arr[10 - 1];
        cout << "\nSecond to the smallest : " << arr[10 - 2];
        
         cout<<"\n Process complete. Wanna try again? (enter 'y' if YES)\n"<<std::endl;
		cout<<">> ";
		
			
		cin>>mainQ;

        
}

    }

