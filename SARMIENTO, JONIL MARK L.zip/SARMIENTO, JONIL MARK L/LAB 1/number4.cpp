#include <iostream>
#include <cstring>
using namespace std;
char mainQ = 'y';

int main()
{
    char string[50];
    int i, length;
    int j = 0;
    while (mainQ=='Y'||mainQ=='y')
    {
	
    system ("CLS");
    cout << "Enter a string: "; cin >> string;
    
    length = strlen(string);
    
    if(!cin)
        {
        	system ("CLS");
			cout<<"Wrong Input";
			
			return 0;
    
		}
		
	if (cin)
	{
	
    
    for(i=0;i < length ;i++)
	{
       
	    if(string[i] != string[length-i-1])
		{
            j = 1;
            break;
   		}
	}
    
    if (j) 
	{
        system ("CLS");
		cout << string << " is not a palindrome" << endl; 
    }    
    else {
        system ("CLS");
		cout << string << " is a palindrome" << endl; 
    }
}
    
    system("pause");
  
    cout<<"\n Process complete. Wanna try again? (enter 'y' if YES)\n"<<std::endl;
		cout<<">> ";
		
			
		cin>>mainQ;
    



}

}

