#include <iostream>
using namespace std;

char mainQ = 'y'; 
double arr[10];
int a, b, temp;
   
int main()
{
	 while (mainQ=='Y'||mainQ=='y')
	 {
	   
	system ("CLS");
	cout<<"Enter elements in array: \n";
	
	
for(a=0; a<10; a++)
    {	
    	
    cin>>arr[a];
      
        if(!cin)
        {
        	system ("CLS");
			cout<<"Wrong Input";
			cout<<"\n Process complete. Wanna try again? (enter 'y' if YES)\n"<<std::endl;
		cout<<">> ";
		cin>>mainQ;	
        return 0;
		}
    }
    if(cin)
    {
    	for(a=0; a<10; a++)
    {
        for(b=+1; b<10; b++)
        {
            
            if(arr[b] < arr[a])
            {
                temp = arr[a];
                arr[a] = arr[b];
                arr[b] = temp;
            }
        }
    }
    
   system ("CLS");
    cout<<"Elements of array ascending order:"<<endl;
    for(a=0; a<10; a++)
    {

		cout<<arr[a] <<" ";
    }
    	
    

}
 cout<<"\n Process complete. Wanna try again? (enter 'y' if YES)\n"<<std::endl;
		cout<<">> ";
		
			
		cin>>mainQ;
}

}


